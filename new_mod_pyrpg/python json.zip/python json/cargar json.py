import json
import os
enemigos_classes = []
lista_enemigos_json = []
os.chdir("./enemigos_json/")
for i in os.listdir(os.getcwd()):
    lista_enemigos_json.append(i)

print(lista_enemigos_json)

class enemigos():
    def __init__(self, a):
        self.nombre = a["nombre"]
        self.vida_max = a["vida"]
        self.vida_act = a["vida"]
        self.ataque = a["ataque"]
        self.defensa = a["defensa"]
        enemigos_classes.append(self)

for i in os.listdir(f"{os.getcwd()}"):
    with open(f"{i}", "r") as enem:
        enemigos_dic = json.loads(enem.read())
    enemigo_class = enemigos(enemigos_dic)

for i in range (len(enemigos_classes)):
    if enemigos_classes[i].nombre =="goblin_fuerte":
        print(enemigos_classes[i].nombre)
        print(enemigos_classes[i].ataque)
        print(enemigos_classes[i].defensa)





